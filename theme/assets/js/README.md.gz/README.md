*demo.js* file is ONLY provided for the demo of Ace Admin Template.
You **should NOT** include it in your app.
For more information regarding how to apply various settings in your app, please refer to the documentation.
